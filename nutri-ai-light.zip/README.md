# NutriAI — App de Planos de Dieta e Receitas Diárias (Leve)

Este repositório contém um projeto **completo e leve** (frontend + backend) pronto para subir no GitHub.
Os PDFs/e-books não estão incluídos para manter o arquivo leve — o código já está preparado para lê-los se você colocar arquivos PDF em `server/data/`.

## Estrutura
```
diet-ai/
├─ server/
├─ client/
└─ README.md
```

## Passos rápidos (local)
1. Backend:
```bash
cd server
npm install
npm run generate-vapid
# copie as chaves geradas e cole em server/.env (VAPID_PUBLIC_KEY e VAPID_PRIVATE_KEY)
# adicione OPENAI_API_KEY em server/.env
npm run dev
```

2. Frontend:
```bash
cd client
npm install
# ajuste client/.env com REACT_APP_API_URL e REACT_APP_VAPID_PUBLIC
npm start
```

Abra http://localhost:3000

## Deploy
- Suba `server/` em um serviço como Render, Railway ou Heroku (defina variáveis de ambiente: OPENAI_API_KEY, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY).
- Suba `client/` em Vercel/Netlify ou sirva a pasta build pelo servidor express.

## Notas
- Coloque seus PDFs em `server/data/` e reinicie o servidor para indexação automática.
- As notificações Web Push exigem HTTPS em produção.
