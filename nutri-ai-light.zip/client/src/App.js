import React, { useEffect, useState } from 'react';
import { signup, generatePlan, getRecipes, subscribePush } from './api';
import NotificationToggle from './components/NotificationToggle';
import PlanGenerator from './components/PlanGenerator';
import RecipeCard from './components/RecipeCard';

export default function App(){
  const [email, setEmail] = useState('');
  const [user, setUser] = useState(null);
  const [recipes, setRecipes] = useState([]);
  const [plan, setPlan] = useState('');

  useEffect(()=>{ loadRecipes(); }, []);
  async function loadRecipes(){
    const r = await getRecipes();
    setRecipes(r.recipes || []);
  }

  async function handleSignup(){
    if(!email) return alert('Informe seu email');
    const res = await signup(email);
    setUser(res.user);
    alert('Cadastro feito com sucesso');
  }

  async function handleGenerate(){
    if(!email) return alert('Cadastre seu email antes');
    const res = await generatePlan(email);
    setPlan(res.plan || 'Erro ao gerar');
  }

  return (
    <div style={{maxWidth:980, margin:'20px auto', padding:24, background:'#fff', borderRadius:12, boxShadow:'0 6px 18px rgba(10,20,40,0.08)'}}>
      <header style={{display:'flex', alignItems:'center', gap:16}}>
        <img src="/logo.svg" alt="logo" style={{height:72}}/>
        <div>
          <h1 style={{margin:0}}>NutriAI</h1>
          <small>Planos & Receitas • Notificações Diárias</small>
        </div>
      </header>

      <section style={{marginTop:20}}>
        <input placeholder="Seu email" value={email} onChange={e=>setEmail(e.target.value)} />
        <button onClick={handleSignup}>Cadastrar</button>
        <NotificationToggle email={email} onSubscribed={(sub)=>subscribePush(sub,email)} />
      </section>

      <section style={{marginTop:20}}>
        <h2>Gerar plano personalizado</h2>
        <PlanGenerator email={email} onGenerate={handleGenerate}/>
        <pre style={{whiteSpace:'pre-wrap', background:'#f4f6fb', padding:12, borderRadius:8}}>{plan}</pre>
      </section>

      <section style={{marginTop:20}}>
        <h2>Receitas do e-book (indexadas)</h2>
        <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(240px,1fr))', gap:12}}>
          {recipes.map(r => <RecipeCard key={r.id} recipe={r} />)}
        </div>
      </section>
    </div>
  );
}
