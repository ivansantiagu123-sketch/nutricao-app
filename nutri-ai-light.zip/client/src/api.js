const API = (path) => `${process.env.REACT_APP_API_URL || ''}/api${path}`;

export async function signup(email) {
  const res = await fetch(API('/signup'), {
    method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ email })
  });
  return res.json();
}

export async function generatePlan(email) {
  const res = await fetch(API('/generate-plan'), {
    method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ email })
  });
  return res.json();
}

export async function getRecipes() {
  const res = await fetch(API('/recipes'));
  return res.json();
}

export async function subscribePush(subscription, email) {
  const res = await fetch(API('/subscribe'), {
    method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ subscription, email })
  });
  return res.json();
}
