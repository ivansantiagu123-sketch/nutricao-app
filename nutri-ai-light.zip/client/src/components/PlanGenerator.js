import React, { useState } from 'react';

export default function PlanGenerator({ email, onGenerate }) {
  const [profile, setProfile] = useState({ age:'30', sex:'F', height:'165', weight:'70', goals:'emagrecimento', preferences:''});
  async function saveProfileAndGenerate(){
    if(!email) return alert('Informe seu email antes');
    await fetch((process.env.REACT_APP_API_URL||'') + '/api/profile', {
      method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ email, profile })
    });
    onGenerate();
  }
  return (
    <div>
      <div>
        <label>Idade <input value={profile.age} onChange={e=>setProfile({...profile, age:e.target.value})}/></label>
        <label>Peso <input value={profile.weight} onChange={e=>setProfile({...profile, weight:e.target.value})}/></label>
        <label>Altura <input value={profile.height} onChange={e=>setProfile({...profile, height:e.target.value})}/></label>
      </div>
      <div>
        <label>Objetivo <input value={profile.goals} onChange={e=>setProfile({...profile, goals:e.target.value})}/></label>
        <label>Preferências <input value={profile.preferences} onChange={e=>setProfile({...profile, preferences:e.target.value})}/></label>
      </div>
      <button onClick={saveProfileAndGenerate}>Gerar Plano</button>
    </div>
  );
}
