import React from 'react';
export default function RecipeCard({ recipe }) {
  return (
    <div style={{border:'1px solid #eee', padding:12, borderRadius:8, background:'#fff'}}>
      <h3>{recipe.title}</h3>
      <p style={{fontSize:13, color:'#555'}}>{recipe.excerpt?.slice(0,200)}...</p>
      <small>Fonte: {recipe.source}</small>
    </div>
  );
}
