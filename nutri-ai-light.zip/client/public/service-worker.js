self.addEventListener('push', function(event) {
  let data = {};
  if (event.data) data = event.data.json();
  const title = data.title || 'NutriAI';
  const options = {
    body: data.body || 'Abra o app para ver as novidades',
    icon: '/logo.svg'
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener('notificationclick', function(event) {
  event.notification.close();
  event.waitUntil(clients.openWindow('/'));
});
