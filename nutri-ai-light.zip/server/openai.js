const { OpenAI } = require('openai');
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

async function generateMealPlan(profile) {
  const prompt = `Crie um plano alimentar diário profissional e detalhado para este(a) usuário(a):
${JSON.stringify(profile, null, 2)}
Regras: Forneça 3 opções de café, 3 lanches e 3 jantares com calorias aproximadas e receitas curtas. Use linguagem em português.`;
  const res = await client.chat.completions.create({
    model: process.env.OPENAI_MODEL || "gpt-4o-mini",
    messages: [{ role: "user", content: prompt }],
    max_tokens: 900
  });
  return res.choices?.[0]?.message?.content ?? "Erro ao gerar plano.";
}

async function suggestRecipe(ingredients = []) {
  const prompt = `Sugira uma receita rápida e saudável usando: ${ingredients.join(', ')}. Retorne título, tempo, ingredientes e modo de preparo em português.`;
  const res = await client.chat.completions.create({
    model: process.env.OPENAI_MODEL || "gpt-4o-mini",
    messages: [{ role: "user", content: prompt }],
    max_tokens: 400
  });
  return res.choices?.[0]?.message?.content ?? "";
}

module.exports = { generateMealPlan, suggestRecipe };
