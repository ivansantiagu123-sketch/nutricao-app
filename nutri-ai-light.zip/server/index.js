require('dotenv').config();
const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const cors = require('cors');
const webpush = require('web-push');
const nodeCron = require('node-cron');
const fs = require('fs');
const pdf = require('pdf-parse');

const { db, init } = require('./db');
const { generateMealPlan, suggestRecipe } = require('./openai');
const { nanoid } = require('nanoid');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, '..', 'client', 'build')));

const VAPID_PUBLIC = process.env.VAPID_PUBLIC_KEY;
const VAPID_PRIVATE = process.env.VAPID_PRIVATE_KEY;

if (VAPID_PUBLIC && VAPID_PRIVATE) {
  webpush.setVapidDetails(
    'mailto:contato@seu-dominio.com',
    VAPID_PUBLIC,
    VAPID_PRIVATE
  );
} else {
  console.warn('VAPID keys não configuradas — notificações push não enviarão até configuradas.');
}

async function loadPdfs() {
  const dataDir = path.join(__dirname, 'data');
  if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir);
  const files = fs.readdirSync(dataDir).filter(f => f.endsWith('.pdf'));
  for (const file of files) {
    const buf = fs.readFileSync(path.join(dataDir, file));
    try {
      const parsed = await pdf(buf);
      const text = parsed.text.slice(0, 20000);
      if (!db.data.recipes.find(r => r.source === file)) {
        db.data.recipes.push({
          id: nanoid(),
          title: file.replace('.pdf',''),
          source: file,
          excerpt: text.slice(0,1000),
          fullText: text
        });
      }
    } catch(e) {
      console.error('erro parse pdf', file, e);
    }
  }
  await db.write();
}

(async () => {
  await init();
  await loadPdfs();

  app.get('/api/health', (req, res) => res.json({ ok: true }));

  app.post('/api/signup', async (req, res) => {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: 'email required' });
    let user = db.data.users.find(u => u.email === email);
    if (!user) {
      user = { id: nanoid(), email, createdAt: Date.now(), profile: {} };
      db.data.users.push(user);
      await db.write();
    }
    res.json({ user });
  });

  app.post('/api/profile', async (req, res) => {
    const { email, profile } = req.body;
    if (!email) return res.status(400).json({ error: 'email required' });
    const user = db.data.users.find(u => u.email === email);
    if (!user) return res.status(404).json({ error: 'user not found' });
    user.profile = profile;
    await db.write();
    res.json({ ok: true, user });
  });

  app.post('/api/generate-plan', async (req, res) => {
    const { email } = req.body;
    const user = db.data.users.find(u => u.email === email) || {};
    try {
      const plan = await generateMealPlan(user.profile || {});
      res.json({ plan });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'erro geração' });
    }
  });

  app.get('/api/recipes', async (req, res) => {
    res.json({ recipes: db.data.recipes.slice(0,50) });
  });

  app.post('/api/suggest', async (req, res) => {
    const { ingredients } = req.body;
    try {
      const recipe = await suggestRecipe(ingredients || []);
      res.json({ recipe });
    } catch (e) {
      res.status(500).json({ error: 'erro' });
    }
  });

  // subscriptions
  app.post('/api/subscribe', async (req, res) => {
    const sub = req.body.subscription;
    const email = req.body.email || 'anonymous';
    if (!sub) return res.status(400).json({ error: 'subscription required' });
    db.data.subscriptions.push({ id: nanoid(), subscription: sub, email, createdAt: Date.now() });
    await db.write();
    res.json({ ok: true });
  });

  app.post('/api/unsubscribe', async (req, res) => {
    const endpoint = req.body.endpoint;
    db.data.subscriptions = db.data.subscriptions.filter(s => s.subscription.endpoint !== endpoint);
    await db.write();
    res.json({ ok: true });
  });

  app.post('/api/push-test', async (req, res) => {
    const payload = JSON.stringify({ title: 'Teste NutriAI', body: 'Notificação de teste 🎯' });
    const subs = db.data.subscriptions;
    for (const s of subs) {
      try {
        await webpush.sendNotification(s.subscription, payload);
      } catch (e) {
        console.error('erro enviar push', e);
      }
    }
    res.json({ sent: subs.length });
  });

  // schedule daily at 08:00 server time
  nodeCron.schedule('0 8 * * *', async () => {
    console.log('Job diário: enviando notificações');
    const subs = db.data.subscriptions;
    const payload = JSON.stringify({ title: 'Sua receita diária', body: 'Abra o app e veja a receita e plano do dia.'});
    for (const s of subs) {
      try {
        await webpush.sendNotification(s.subscription, payload);
      } catch (e) {
        console.error('erro enviar push', e);
      }
    }
  });

  // serve frontend build
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'client', 'build', 'index.html'));
  });

  const PORT = process.env.PORT || 4000;
  app.listen(PORT, () => console.log(`Server started on ${PORT}`));
})();
